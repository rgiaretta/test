function ob(a){if( typeof(a)!='object' ){try{o=document.getElementById(a).id;o= document.getElementById(a);if( typeof(o)!='object' ) throw a;}catch(e){o=document.getElementsByName(a)[0];}}	return o;}// Retorna sempre um objeto, seja pelo nome ou pelo ID

function ltrim(a){
	if(a.substr(0,1)==' ')return ltrim(a.substr(1));
	return a;
};

function rtrim(a){
	if(a.substr((a.length-1),1)==' ')return rtrim(a.substr(0,(a.length-1)));
	return a;
};
function trim(a){
	return rtrim(ltrim(a));
};

function defineFuncaoCheckBox(tipo, nomeCheckBox, nomeControle){
	tipo = tipo.toUpperCase();
	var _Obj;

	if( tipo == 'TEXT' ){//TextBox
		_Obj = document.getElementsByTagName('INPUT');
	}else{
		_Obj = document.getElementsByTagName(tipo);
	}

	for(var i=0 ; i < _Obj.length ; i++){
			if( _Obj[i].type.toUpperCase() == "TEXT"  || tipo == "SELECT" || tipo == "TEXTAREA") {
				if( _Obj[i].name.substring(0,3) !='opt' ){ // Evita o select			
					ob(_Obj[i].name).onchange = function(){ check(this, nomeCheckBox, nomeControle) };												
				}
			}

	}
};


function check(obj, nomeCheckBox, nomeControle){	
	var chk = nomeCheckBox;
	var nome = obj.name;
	
	if(nome!=""){
		chk = chk + nome.substring(nomeControle.length, nome.length);
		ob(chk).checked = ( vl(obj.name).length > 0 );
	}		
};

function validarFloat(valor){
	var pesquisa = /^\d*.\d{1,2}$/;	
	var inteiro = /^\d*$/;	
	var virgula = /^\d*,\d{1,2}$/;	
	
	if( valor.match(pesquisa) || valor.match(inteiro) || valor.match(virgula) ){
		return true;
	}else{
		return false;	
	}
};


function validarInteiro(valor){
	var inteiro = /^\d*$/;	
	if( valor.match(inteiro) ){
		return true;
	}else{
		return false;	
	}
};

	function selecionaTodosCheckBoxes(inicial){
		if( inicial.length < 1) return;		
		tipo = "OPTION";
		var _Obj =retornaTipoPelaInicial(inicial, tipo);
					
		for(var i=0 ; i < _Obj.length ; i++){			
			if( _Obj[i].id.substring( 0, inicial.length ) == inicial ){
				_Obj[i].selected = true;
			}
		}	
	};


	function qtdTipoPelaInicial(inicial, tipo){
		return retornaTipoPelaInicial(inicial, tipo).length;
	};


	function retornaTipoPelaInicial(inicial, tipo){
		var _arrayObj = new Array();;
		var qtdObjetosRetorno = 0;
		if( tipo == null ){
			return false;
		}
		if( inicial.length < 1 ) {
			return false;
		}
		
		tipo = tipo.toUpperCase();
		var _todosDoTipo = document.getElementsByTagName(tipo);

		for(var i=0 ; i < _todosDoTipo.length ; i++){					
			if( _todosDoTipo[i].id.substring( 0, inicial.length ) == inicial ){
			_arrayObj[qtdObjetosRetorno] = _todosDoTipo[i];
			qtdObjetosRetorno++ ;			
			}
		}		
		return _arrayObj;
	};



function FormataReais(fld, milSep, decSep, e) {
	var sep = 0;
	var key = '';
	var i = j = 0;
	var len = len2 = 0;
	var strCheck = '0123456789';
	var aux = aux2 = '';
	var whichCode = (window.Event) ? e.which : e.keyCode;

	if ((whichCode == 13) || (whichCode == 0) || (whichCode == 8))return true;
	key = String.fromCharCode(whichCode);

	if (strCheck.indexOf(key) == -1) return false; 
	len = fld.value.length;
	for(i = 0; i < len; i++)
		if ((fld.value.charAt(i) != '0') && (fld.value.charAt(i) != decSep)) break;
	aux = '';
	for(; i < len; i++)
		if (strCheck.indexOf(fld.value.charAt(i))!=-1) aux += fld.value.charAt(i);
	aux += key;
	len = aux.length;
	if (len == 0) fld.value = '';
	if (len == 1) fld.value = '0'+ decSep + '0' + aux;
	if (len == 2) fld.value = '0'+ decSep + aux;
	if (len > 2) {aux2 = '';
	for (j = 0, i = len - 3; i >= 0; i--) {
		if (j == 3) {aux2 += milSep;j = 0;
		}
		aux2 += aux.charAt(i);
		j++;
	}
	fld.value = '';
	len2 = aux2.length;
	for (i = len2 - 1;
	i >= 0;
	i--
	)
		fld.value += aux2.charAt(i);
	fld.value += decSep + aux.substr(len - 2, len);
	}
	return false;
};

 
 function FormataCNPJ(Campo, teclapres){

   if(window.event){
    var tecla = teclapres.keyCode;
   }else  tecla = teclapres.which;

   var vr = new String(Campo.value);
   vr = vr.replace(".", "");
   vr = vr.replace(".", "");
   vr = vr.replace("/", "");
   vr = vr.replace("-", "");

   tam = vr.length + 1;

   
   if (tecla != 9 && tecla != 8){
      if (tam > 2 && tam < 6)
         Campo.value = vr.substr(0, 2) + '.' + vr.substr(2, tam);
      if (tam >= 6 && tam < 9)
         Campo.value = vr.substr(0,2) + '.' + vr.substr(2,3) + '.' + vr.substr(5,tam-5);
      if (tam >= 9 && tam < 13)
         Campo.value = vr.substr(0,2) + '.' + vr.substr(2,3) + '.' + vr.substr(5,3) + '/' + vr.substr(8,tam-8);
      if (tam >= 13 && tam < 15)
         Campo.value = vr.substr(0,2) + '.' + vr.substr(2,3) + '.' + vr.substr(5,3) + '/' + vr.substr(8,4)+ '-' + vr.substr(12,tam-12);
      }
 };

 	function irPara(action) {
 		this.location = action;
	};


	function atualizaMenu() {	
		window.parent.frames[0].location="menu.do";		
	};
	

	function getBrowser(){

		var agt=navigator.userAgent.toLowerCase();

		if (agt.indexOf("opera") != -1) return 'Opera';
		if (agt.indexOf("staroffice") != -1) return 'Star Office';
		if (agt.indexOf("webtv") != -1) return 'WebTV';
		if (agt.indexOf("beonex") != -1) return 'Beonex';
		if (agt.indexOf("chimera") != -1) return 'Chimera';
		if (agt.indexOf("netpositive") != -1) return 'NetPositive';
		if (agt.indexOf("phoenix") != -1) return 'Phoenix';
		if (agt.indexOf("firefox") != -1) return 'Firefox';
		if (agt.indexOf("safari") != -1) return 'Safari';
		if (agt.indexOf("skipstone") != -1) return 'SkipStone';
		if (agt.indexOf("msie") != -1) return 'Internet Explorer';
		if (agt.indexOf("netscape") != -1) return 'Netscape';
		if (agt.indexOf("mozilla/5.0") != -1) return 'Mozilla';
		if (agt.indexOf('\/') != -1) {
		if (agt.substr(0,agt.indexOf('\/')) != 'mozilla') {
		return navigator.userAgent.substr(0,agt.indexOf('\/'));}
		else return 'Netscape';} else if (agt.indexOf(' ') != -1)
		return navigator.userAgent.substr(0,agt.indexOf(' '));
		else return navigator.userAgent;

	}		
