package br.com.rgiaretta.cpim.usuario.hibernate;

import java.sql.Date;

import br.com.rgiaretta.cpim.common.DataTransferObject;

public class Usuario extends DataTransferObject implements java.io.Serializable {

	private static final long serialVersionUID = 4067726157101314528L;

	private Integer id;
	private String nome;
	private String email;	
	private Date dataCadastro;
	private Boolean ativo;
	private String sexo;
	private String uf;
  
	
	public Usuario() {}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public java.sql.Date getDataCadastro() {
		return dataCadastro;
	}

	public void setDataCadastro(java.sql.Date dataCadastro) {
		this.dataCadastro = dataCadastro;
	}
	
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}	

	public Boolean getAtivo() {
		return ativo;
	}

	public void setAtivo(Boolean ativo) {
		this.ativo = ativo;
	}	

	public String getSexo() {
		return sexo;
	}

	public void setSexo(String sexo) {
		this.sexo = sexo;
	}

	public String getUf() {
		return uf;
	}

	public void setUf(String uf) {
		this.uf = uf;
	}	
	
}