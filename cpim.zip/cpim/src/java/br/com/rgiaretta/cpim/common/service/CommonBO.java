package br.com.rgiaretta.cpim.common.service;

import java.util.Collection;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.HibernateException;

import br.com.rgiaretta.cpim.common.ApplicationException;
import br.com.rgiaretta.cpim.common.DataAccessException;
import br.com.rgiaretta.cpim.common.DataTransferObject;
import br.com.rgiaretta.cpim.common.HibernateDAO;
import br.com.rgiaretta.cpim.common.IBusiness;
import br.com.rgiaretta.cpim.common.model.CommonDAO;
import br.com.rgiaretta.cpim.common.dto.UfDTO;


public class CommonBO implements IBusiness{


	private Log log = LogFactory.getLog(CommonBO.class);

	public CommonBO() {}

	public Integer add(DataTransferObject addRecord) throws ApplicationException {return null;}

	public DataTransferObject retrieve(Integer primaryKey) {return null;}

	public void update(DataTransferObject updateRecord) throws ApplicationException {}

	
	  public Collection<UfDTO> getUfs() throws ApplicationException {
		  
		  Collection<UfDTO> ufs = null;

		  HibernateDAO dao = HibernateDAO.getDAO();

		  try {

			  CommonDAO commonDAO = new CommonDAO(dao);
			  
			  ufs = commonDAO.getUfs();

			  dao.finalizaTransaction();

		  	} catch(HibernateException e) {
				dao.getSession().getTransaction().rollback();
				log.error("Erro ao obter acessos", e);
	            throw new DataAccessException("Erro em CommonBO.commit(): " + e.toString(), e);        

			} catch (Exception e) {
				dao.getSession().getTransaction().rollback();
				log.error("Erro ao obter acessos", e);
	            throw new DataAccessException("Erro em CommonBO.commit(): " + e.toString(), e);        

			} finally {
			  dao.finalizaSessao();
		  }	

		  return ufs;
	  }	
	
}