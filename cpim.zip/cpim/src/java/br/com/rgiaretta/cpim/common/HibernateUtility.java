package br.com.rgiaretta.cpim.common;



import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.CacheMode;
import org.hibernate.FlushMode;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


public class HibernateUtility {

	private static Log log = LogFactory.getLog(HibernateUtility.class);
	
    private static SessionFactory factory;
    
    static {
    	//Bloco est�tico que inicializa o Hibernate
    	try {
    		
    		Propriedade prop = new Propriedade("conf.properties");
    		String dialeto = prop.getPropriedade("bd.dialeto");
    		Configuration conf = new Configuration().configure("hibernate.cfg.xml")
    									.setProperty("hibernate.dialect", 
    											dialeto);
    		
    		factory = conf.buildSessionFactory();
    		
    	} catch (Exception e) {
    		log.error("Initial SessionFactory creation failed.", e);
    		e.printStackTrace();
    		factory = null;
    	}
    }
    
    public static final ThreadLocal<Session> session = new ThreadLocal<Session>();
    public static final ThreadLocal<Transaction> transaction = new ThreadLocal<Transaction>();
    
    public static Session getSession() {
        try {
            if(factory == null) {
                factory = new Configuration().configure().buildSessionFactory();
            }
            if(session.get() == null) {
                iniciaTransacao();
            }
            session.get().setCacheMode(CacheMode.IGNORE);
            session.get().setFlushMode(FlushMode.ALWAYS);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return session.get();       
    }
    
    private static Transaction getTransacao() {
        return transaction.get();
    }
    
    public static void iniciaTransacao() {
        if(session.get() != null) {
            throw new RuntimeException("nao sei como aninhar transacoes");
        }
        session.set(factory.openSession());
        transaction.set(getSession().beginTransaction());
        
    }
    
    public static void fechaSessao() {
        try {
            if(getSession() != null) getSession().close();
             
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            session.set(null);
            transaction.set(null);
        }
    }
    
    public static void closeSession() {
        fechaSessao();
        
    }
    
    public static void confirma() {
        try {
            if(getTransacao() != null) getTransacao().commit();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            fechaSessao();
        }
        
    }
    
    public static void confirmaComExcecao() throws Exception {
        try {
            if(getTransacao() != null) getTransacao().commit();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            throw e;
        } finally {
            fechaSessao();
        }
        
    }
    
    public static void aborta() {
        try {
            if(getTransacao() != null) getTransacao().rollback();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            fechaSessao();
        }
    }

    /**
     * @param args
     */
    public static void main(String[] args) {
    	HibernateUtility.getSession();
    }

}
