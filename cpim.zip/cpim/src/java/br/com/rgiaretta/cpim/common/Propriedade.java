package br.com.rgiaretta.cpim.common;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class Propriedade {
	private Properties props;
	
	/**
	 * 
	 */
	public Propriedade(String nomeArquivo) {

		super();
		
		ClassLoader loader = this.getClass().getClassLoader();
		InputStream is = loader.getResourceAsStream(nomeArquivo );
		
		
		File file = new File(nomeArquivo);
		

		this.props = new Properties();
		
		InputStream fis = is;
		try {
			if(fis == null) fis = new FileInputStream(file);
			this.init(fis);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	
	public Propriedade(InputStream is) {
		if(this.props == null) this.props = new Properties();
		try {
			this.init(is);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void init(InputStream fis) throws IOException {
		try{
			//l� os dados que est�o no arquivo
			this.props.load(fis);
			fis.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public String getPropriedade(String chave) {
		return this.props.getProperty(chave);
	}
}
