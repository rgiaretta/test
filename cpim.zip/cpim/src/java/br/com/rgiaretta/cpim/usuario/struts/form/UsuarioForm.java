package br.com.rgiaretta.cpim.usuario.struts.form;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

import br.com.rgiaretta.cpim.common.Validator;


public class UsuarioForm extends ActionForm {

	private static final long serialVersionUID = -6563918932664336300L;

	private String id;
	private String nome;
	private String email;
	private String dataCadastro;
	private String  dispatch;
	private String  tipoFormulario;
	private String  actionRetorno;
	private Boolean ativo;
	private String sexo;
	private String uf;


	/**
	 * Chamado pelo framework para validar os campos obrigat�rios
	 */
	public ActionErrors validate(ActionMapping mapping, HttpServletRequest request) {

		ActionErrors errors = new ActionErrors();
		
		Validator validator = new Validator();


		if (nome == null || nome.trim().equals("")) {
			errors.add("nomeUsuario", new ActionMessage("error.usuario.null"));
		}
		
		if (email!= null && !email.trim().equals("")) {
			if(!validator.validateEmail(email)){
				errors.add("emailContato", new ActionMessage("error.cpim.email.invalido"));
			}else{
				email = email.toLowerCase();
			}
		}

		
		if(errors.size() == 0){

			if (dataCadastro != null){
				try {
					SimpleDateFormat formatador = new SimpleDateFormat("dd/MM/yyyy");
					Date dataTemp = formatador.parse(dataCadastro);
					SimpleDateFormat novoFormatador = new SimpleDateFormat("yyyy-MM-dd");       
					dataCadastro = novoFormatador.format(dataTemp);    
				} catch (java.text.ParseException p) {
					errors.add("data", new ActionMessage("error.cpim.data.dataInvalida"));
				}
			}			
			
		}

		return errors;
	}



	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}


	public String getDataCadastro() {
		return dataCadastro;
	}

	public void setDataCadastro(String dataCadastro) {
		this.dataCadastro = dataCadastro;
	}


	public String getDispatch() {
		return dispatch;
	}

	public void setDispatch(String dispatch) {
		this.dispatch = dispatch;
	}

	public String getTipoFormulario() {
		return tipoFormulario;
	}

	public void setTipoFormulario(String tipoFormulario) {
		this.tipoFormulario = tipoFormulario;
	}

	public String getActionRetorno() {
		return actionRetorno;
	}

	public void setActionRetorno(String actionRetorno) {
		this.actionRetorno = actionRetorno;
	}

	public Boolean getAtivo() {
		return ativo;
	}

	public void setAtivo(Boolean ativo) {
		this.ativo = ativo;
	}


	public String getId() {
		return id;
	}



	public void setId(String id) {
		this.id = id;
	}



	public String getSexo() {
		return sexo;
	}



	public void setSexo(String sexo) {
		this.sexo = sexo;
	}



	public String getUf() {
		return uf;
	}



	public void setUf(String uf) {
		this.uf = uf;
	}

}