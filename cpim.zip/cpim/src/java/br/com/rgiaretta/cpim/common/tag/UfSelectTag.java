package br.com.rgiaretta.cpim.common.tag;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.tagext.TagSupport;

import br.com.rgiaretta.cpim.common.service.CommonBO;
import br.com.rgiaretta.cpim.common.dto.UfDTO;


public class UfSelectTag extends TagSupport {

	private static final long serialVersionUID = -7158454431427449104L;

	public int doStartTag() throws JspException, JspTagException {

		Collection<UfDTO> ufs = null;
		List<String> ufLabel = new ArrayList<String>();
		List<String> ufValue = new ArrayList<String>();

		CommonBO commonBO = new CommonBO();
		ufs = commonBO.getUfs();

		if(ufs != null && ufs.size() > 0){
			for (UfDTO ufDTO : ufs) {
				ufLabel.add(ufDTO.getSigla());
				ufValue.add(ufDTO.getSigla());    		  			
			}

		}

		pageContext.setAttribute("ufLabelList", ufLabel);
		pageContext.setAttribute("ufValueList", ufValue);

		return SKIP_BODY;
	} 
}