package br.com.rgiaretta.cpim.common;

import org.apache.commons.lang.exception.NestableRuntimeException;

public class ApplicationException extends NestableRuntimeException {

	private static final long serialVersionUID = -5365005643715863993L;
	Throwable exceptionCause = null;

	public ApplicationException(String msg) {
		super(msg);
	}

	public ApplicationException(String msg, Throwable exception) {
		super(msg, exception);
		exceptionCause = exception;
	}

	public void printStackTrace() {

		if (exceptionCause != null) {
			System.err.println("An exception has been caused by: "
					+ exceptionCause.toString());
			exceptionCause.printStackTrace();
		}
	}
}