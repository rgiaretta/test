package br.com.rgiaretta.cpim.usuario.struts.action;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import br.com.rgiaretta.cpim.common.IConstants;
import br.com.rgiaretta.cpim.usuario.service.UsuarioBO;
import br.com.rgiaretta.cpim.usuario.hibernate.Usuario;
import br.com.rgiaretta.cpim.usuario.struts.form.UsuarioForm;

public class UsuarioAction extends DispatchAction {
	
	@SuppressWarnings("unused")
	private Log log = LogFactory.getLog(UsuarioAction.class);

	public UsuarioAction() { }
	
	public ActionForward load(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		
		saveToken(request);

		this.setHeader(response);
		
	 	HttpSession sessao = request.getSession();
	 	sessao.setAttribute("labelItem", "Cadastro de Usu�rios");

		
		UsuarioForm usuarioForm = (UsuarioForm) form;
		UsuarioBO bo = new UsuarioBO();
			    	    
		if((String) request.getParameter("id") != null){

			String idUsuario = (String) request.getParameter("id");
			
			Usuario usuario = (Usuario) bo.retrieve(Integer.parseInt(idUsuario));
			BeanUtils.copyProperties(usuarioForm, usuario);

			if(usuario.getDataCadastro() != null) {
				try {
					SimpleDateFormat formatador = new SimpleDateFormat("yyyy-MM-dd");
					Date dataTemp = formatador.parse(usuarioForm.getDataCadastro());
					SimpleDateFormat novoFormatador = new SimpleDateFormat("dd/MM/yyyy");       
					usuarioForm.setDataCadastro(novoFormatador.format(dataTemp));    
				} catch (java.text.ParseException p) {
					usuarioForm.setDataCadastro("");
				}
			}		
						
			Boolean readOnly = new Boolean(request.getParameter("readOnly"));

			if(readOnly){
				usuarioForm.setTipoFormulario("readOnly");
			}else{

				usuarioForm.setTipoFormulario("edit");
				usuarioForm.setDispatch("update");				
			}
			
			
			
			Boolean consulta = new Boolean(request.getParameter("consulta"));

			if(consulta){
				String acesso = (String) request.getParameter("acesso");
				usuarioForm.setActionRetorno("showUsuario.do?dispatch=search&acesso=" + acesso);
			}else{
				usuarioForm.setActionRetorno("manutencao.do");
			}

			
		}else{	//inclus�o
			usuarioForm.setTipoFormulario("add");
			usuarioForm.setDispatch("insert");
			usuarioForm.setAtivo(true);
			usuarioForm.setSexo("M");			
		}
		
		return mapping.findForward(IConstants.SUCCESS_KEY);	
	}
	
	public ActionForward insert(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		if (!isTokenValid(request, true)){
			return mapping.findForward(IConstants.FAILURE_KEY);
		}

		this.setHeader(response);			
		
		UsuarioForm usuarioForm = (UsuarioForm) form;
		UsuarioBO bo = new UsuarioBO();
		
		Usuario usuario = new Usuario();
		

		long now = System.currentTimeMillis();		
	    java.sql.Date date = new java.sql.Date(now);	    
	    usuarioForm.setDataCadastro(date.toString());    	    

		BeanUtils.copyProperties(usuario, usuarioForm);
		
				
		usuario.setId(null);
		usuario.setNome(usuario.getNome().toUpperCase());
				
		Integer idUsuario = bo.add(usuario);
		
		if(idUsuario == 0){
			return mapping.findForward(IConstants.FAILURE_KEY);	
		}
		
		ActionForward forward = mapping.findForward(IConstants.SUCCESS_KEY);
        ActionForward newActionForward = new ActionForward(forward);
        newActionForward.setPath(forward.getPath() + "?dispatch=load&id=" + idUsuario +"&readOnly=true");
      												 
        return newActionForward;
			
	}	
	
	public ActionForward insert2(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

			
		String nome = (String) request.getParameter("nome");
		String email = (String) request.getParameter("email");
		Boolean ativo = new Boolean(request.getParameter("ativo"));
		String uf = (String) request.getParameter("uf");
		String sexo = (String) request.getParameter("sexo");						
		
		UsuarioForm usuarioForm = new UsuarioForm();
		usuarioForm.setNome(nome);
		usuarioForm.setEmail(email);
		usuarioForm.setAtivo(ativo);
		usuarioForm.setUf(uf);
		usuarioForm.setSexo(sexo);
		
		
		
		UsuarioBO bo = new UsuarioBO();
		
		Usuario usuario = new Usuario();
		

		long now = System.currentTimeMillis();		
	    java.sql.Date date = new java.sql.Date(now);	    
	    usuarioForm.setDataCadastro(date.toString());    	    

		BeanUtils.copyProperties(usuario, usuarioForm);
		
		
		usuario.setId(null);
		usuario.setNome(usuario.getNome().toUpperCase());
				
		Integer idUsuario = bo.add(usuario);
		
		if(idUsuario == 0){
			return mapping.findForward(IConstants.FAILURE_KEY);	
		}
		
		ActionForward forward = mapping.findForward(IConstants.SUCCESS_KEY);
        ActionForward newActionForward = new ActionForward(forward);
        newActionForward.setPath(forward.getPath() + "?dispatch=load&id=" + idUsuario +"&readOnly=true");
      												 
        response.getWriter().write("sucesso");

        return null;

			
	}	
	
	
	public ActionForward update(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		
		this.setHeader(response);
		
		if (!isTokenValid(request, true)){
			return mapping.findForward(IConstants.FAILURE_KEY);
		}
		
		try{

			UsuarioForm usuarioForm = (UsuarioForm) form;
			UsuarioBO bo = new UsuarioBO();
			
			Usuario usuario = new Usuario();
			
			BeanUtils.copyProperties(usuario, usuarioForm);
			
																
			BeanUtils.copyProperties(usuario, usuarioForm);
			
						
			bo.update(usuario);
			
			ActionForward forward = mapping.findForward(IConstants.SUCCESS_KEY);
	        ActionForward newActionForward = new ActionForward(forward);
	        newActionForward.setPath(forward.getPath() + "?dispatch=load&id=" + usuario.getId() +"&readOnly=true");
	      												 
	        return newActionForward;

		}catch(Exception e){
			e.printStackTrace();
			return mapping.findForward(IConstants.FAILURE_KEY);	
		}				
			
	}	
	
	
	private void setHeader(HttpServletResponse response) {

		Date dataAtual = new Date();
		Date dataExpiracao = new Date(dataAtual.getTime() + (60000 * 10));
		
		response.setContentType("text/html;charset=ISO-8859-1");
        response.setHeader("Expires", dataExpiracao.toString());
        response.addHeader("Last-Modified:", dataAtual.toString());
        response.addHeader("Cache-Control", "no-cache, must-revalidate");
        response.addHeader("Pragma", " no-cache");
        
	}	
	
}
