/**
 * 
 */
package br.com.rgiaretta.cpim.common;

import java.text.NumberFormat;

/**
 * @author Rafael Pasquotto de Lima Costa (pasquotto@gmail.com)
 *
 */
public class Estatisticas {
	

	private long d1 = 0;
	private long d2 = 0;
	private int bytesLidos = 0;
	
	private int totalToRead = 0;
	
	/**
	 * @param totalToRead2
	 */
	public Estatisticas(int totalToRead) {
		this.totalToRead = totalToRead;
		
	}

	/**
	 * @return
	 */
	public int getBytesLidos() {
		return this.bytesLidos;
	}

	/**
	 * @param i
	 */
	public void setBytesLidos(int i) {
		this.bytesLidos = i;		
	}

	/**
	 * @param delta
	 */
	public void setDelta(long delta) {
		this.d2 = delta;		
	}

	/**
	 * @return
	 */
	public boolean maiorQueUmSegundo() {
		boolean retorno = false;
		if(d2 > d1) {
			d1 = d2;
			d2 = 0;
			retorno = true;
		}
		return retorno;
	}

	/**
	 * @return
	 */
	public long getBps() {
		return Math.abs(this.bytesLidos);
	}

	/**
	 * @param totalBytesRead
	 * @return
	 */
	public long getTempoEstimado(int totalBytesRead) {
		long retorno = 0;
		if(this.getBps() != 0) {
			retorno = (this.totalToRead - Math.abs(totalBytesRead)) / this.getBps();
		}
		return retorno;
	}

	/**
	 * @param bps
	 * @return
	 */
	public String formataBps(final long bps) {
		String retorno =  "";
		retorno = this.formataBytes(bps);
		retorno += "/s";
		return retorno;
	}

	/**
	 * @param bytes
	 * @return
	 */
	public String formataBytes(final long b) {
		final double bytes = b;
		final double KILO = 1024D;
		final double MEGA = 1048576D;
		final double GIGA = 1073741824D;
		
		String retorno =  "";
		NumberFormat nf = NumberFormat.getInstance();
		nf.setMaximumFractionDigits(3);
		nf.setMinimumFractionDigits(3);
		
		if(bytes < KILO) {
			retorno += nf.format(bytes) + " B";
		} else if (bytes < MEGA) {
			retorno += nf.format(bytes / KILO) + " KB";
		} else if(bytes < GIGA) {
			retorno += nf.format(bytes / MEGA) + " MB";
		} else if(bytes > GIGA) {
			retorno += nf.format(bytes / GIGA) + " GB";
		}
		
		
		return retorno;
	}

	/**
	 * @param tempo (em segundos)
	 * @return
	 */

	public static void main(String[] args) {
		Estatisticas est = new Estatisticas(333);
		System.out.println(58 + " - " + est.formataBytes(58));
		System.out.println(125 + " - " + est.formataBytes(125));
		System.out.println(3856 + " - " +  est.formataBytes(38057L));
		System.out.println(3856 + " - " +  est.formataBytes(3274193L));
		System.out.println(3856 + " - " +  est.formataBytes(2180198400L));
		
		
	}
	
}
