package br.com.rgiaretta.cpim.common;

import java.util.regex.*;
 

public class Validator {


  public boolean validateNumero(String numero){
	  
	  Pattern re_filter = Pattern.compile("^\\d+$");
	  Matcher matcher = re_filter.matcher(numero);
	  
	  return matcher.find(0);	  
  
  }
  
  public boolean validateDouble(String varDouble){
	  
	  if(varDouble.indexOf(".") < 0){
		  varDouble = varDouble + ".0";
	  }
	  
	  Pattern re_filter = Pattern.compile("^[+-]?((\\d+|\\d{1,3}(\\.\\d{3})+)(\\.\\d*)?|\\.\\d+)$");
	  Matcher matcher = re_filter.matcher(varDouble);
	  
	  return matcher.find(0);	  
  
  }

  
  public boolean validateData(String data){
	  
	  boolean validate = true;

	  Pattern re_filter = Pattern.compile("(0[1-9]|[12][0-9]|3[01])/(0[1-9]|1[012])/[12][0-9]{3}");
	  Matcher matcher = re_filter.matcher(data);	  

	  if(!matcher.find(0)){
		  validate = false;
	  }else{
		  String[] ardt = data.split("/");
		  if(((Integer.parseInt(ardt[1]) == 4)||(Integer.parseInt(ardt[1]) == 6)||(Integer.parseInt(ardt[1]) == 9) || (Integer.parseInt(ardt[1]) == 11)) && (Integer.parseInt(ardt[0]) > 30)){
			  validate = false;			  
		  }else{
			  if(Integer.parseInt(ardt[1]) == 2){
				  if((Integer.parseInt(ardt[0]) > 28) && ((Integer.parseInt(ardt[2])%4) != 0)){
					  validate = false;
				  }
				  if((Integer.parseInt(ardt[0]) > 29) && ((Integer.parseInt(ardt[2])%4) == 0)){
					  validate = false;
				  }				  
			  }
		  }
	  }

	  return validate;
  }
  
  public boolean validateCNPJ(String cnpj){
	  
	  boolean validate = true;
	  
	  Pattern re_filter = Pattern.compile("\\d{2,3}.\\d{3}.\\d{3}/\\d{4}-\\d{2}");
	  Matcher matcher = re_filter.matcher(cnpj);
	  
	  if(!matcher.find(0)){

		  validate = false;

	  }else{
		    int soma = 0, dig;
		    
		    cnpj.trim();  
		    cnpj = cnpj.replaceAll("[-|/|.| ]", "");
	    
		    String cnpjCalculado = cnpj.substring(0, 12);

		    char[] chr_cnpj = cnpj.toCharArray();

		    for(int i = 0; i < 4; i++) {
		      if (chr_cnpj[i]-48 >= 0 && chr_cnpj[i]-48 <= 9) {
		        soma += (chr_cnpj[i] - 48) * (6 - (i + 1));
		      }     
		    }       
		    
		    for(int i = 0; i < 8; i++) {
		      if (chr_cnpj[i+4]-48 >= 0 && chr_cnpj[i+4]-48 <= 9) {
		        soma += (chr_cnpj[i+4] - 48) * (10 - (i + 1));
		      }  
		    }       
		           
		    dig = 11 - (soma % 11);
		    cnpjCalculado += (dig == 10 || dig == 11) ? "0" : Integer.toString(dig);
		    
		    soma = 0;
		    for (int i = 0; i < 5; i++) {
		      if (chr_cnpj[i]-48 >= 0 && chr_cnpj[i]-48 <= 9) {
		        soma += (chr_cnpj[i] - 48) * (7 - (i + 1)) ;
		      }  
		    }       
		    for (int i = 0; i < 8; i++) {
		      if (chr_cnpj[i+5]-48 >= 0 && chr_cnpj[i+5]-48 <= 9) {
		        soma += (chr_cnpj[i+5] - 48) * (10 - (i + 1)) ;
		      }  
		    }       
		    
		    dig = 11 - (soma % 11);
		    cnpjCalculado += ( dig == 10 || dig == 11 ) ? "0" : Integer.toString(dig);

		    validate = cnpj.equals(cnpjCalculado);		  
	  }
	  
	  return validate;	  
  
  }
  
    public boolean validateCEP(String cep){
	  
	  Pattern re_filter = Pattern.compile("\\d{5}-\\d{3}");
	  Matcher matcher = re_filter.matcher(cep);
	  
	  return matcher.find(0);	  
  
  }

    public boolean validateFone(String fone){
  	  
  	  Pattern re_filter = Pattern.compile("\\d{4}-\\d{4}");
  	  Matcher matcher = re_filter.matcher(fone);
  	  
  	  return matcher.find(0);	  
    
    }

    public boolean validateDDD(String ddd){
  	  
  	  Pattern re_filter = Pattern.compile("\\d{2}");
  	  Matcher matcher = re_filter.matcher(ddd);
  	  
  	  return matcher.find(0);	  
    
    }
  
    public boolean validateIE(String ie){
  	  
  	  Pattern re_filter = Pattern.compile("\\d{3}.\\d{3}.\\d{3}");
  	  Matcher matcher = re_filter.matcher(ie);
  	  
  	  return matcher.find(0);	  
    
    }    
 
    
    public boolean validateCPF(String cpf){
  	  
  	  boolean validate = true;

  	  Pattern re_filter = Pattern.compile("\\d{2,3}.\\d{3}.\\d{3}-\\d{2}");
  	  Matcher matcher = re_filter.matcher(cpf);

  	  if(!matcher.find(0)){

  		  validate = false;

  	  }else{

  		  int    dig1 = 0, dig2 = 0, digito1 = 0, digito2 = 0, resto = 0;
  		  int    digitoCPF;
  		  String somaDigitos;

  		  cpf.trim();  
  		  cpf = cpf.replaceAll("[-|/|.| ]", "");

  		  for (int count = 1; count < cpf.length() -1; count++) {

  			  digitoCPF = Integer.valueOf (cpf.substring(count -1, count)).intValue();
  			  dig1 = dig1 + (11 - count) * digitoCPF;
  			  dig2 = dig2 + (12 - count) * digitoCPF;
  		  };

  		  resto = (dig1 % 11);
  		  if (resto < 2) {
  			  digito1 = 0;
  		  } else {
  			  digito1 = 11 - resto;
  		  }     

  		  dig2 += 2 * digito1;

  		  resto = (dig2 % 11);
  		  if (resto < 2) {
  			  digito2 = 0;
  		  } else {
  			  digito2 = 11 - resto;
  		  }  

  		  String digitoVerificador = cpf.substring (cpf.length()-2, cpf.length());

  		  somaDigitos = String.valueOf(digito1) + String.valueOf(digito2);

  		  validate =  digitoVerificador.equals(somaDigitos);
		  
  	  }
  	  
  	  return validate;	  
    
    }    
 
    
    public boolean validateEmail(String email){

    	Pattern re_filter = Pattern.compile("^\\w+([\\.-]?\\w+)*@\\w+([\\.-]?\\w+)*(\\.\\w{1,3})+$");
    	Matcher matcher = re_filter.matcher(email);

    	return matcher.find(0);	  

    }    
    
    public boolean validateUrl(String url){

    	Pattern re_filter = Pattern.compile("^((http)|(https)|(ftp)):\\/\\/([\\- \\w]+\\.)+\\w{2,3}(\\/ [%\\-\\w]+(\\.\\w{2,})?)*$");
    	Matcher matcher = re_filter.matcher(url);

    	return matcher.find(0);	  

    }

}