package br.com.rgiaretta.cpim.common;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;


public class HibernateDAO extends HibernateDAOAbstrata {

	
	public static HibernateDAO getDAO() {
		
		Session sessao = null; 
		HibernateUtility.getSession();
		
		HibernateDAO dao = new HibernateDAO(sessao);
		return dao;
	}


	protected HibernateDAO(Session sessao) {
		super(sessao);	
	}
	public Session getSession() {
		return HibernateUtility.getSession();
	}

	public void save(Object objeto) {
		this.initTransaction();
		this.sessao.saveOrUpdate(objeto);
		this.finalizaTransaction();
	}
	
	public Query getQuery(String sql) {
		return HibernateUtility.getSession().createQuery(sql);
	}
	
	@SuppressWarnings("unchecked")
	public List<Object> getList(String sql) {
		Query query = this.getQuery(sql);
		List<Object> l = query.list();
		return l;
	}
	
	@SuppressWarnings("unchecked")
	public List<Object> getList(Query query) {
		List<Object> l = query.list();
		return l;
	}
	
	public void delete(Object objeto) {
		this.initTransaction();
		this.sessao.delete(objeto);
		this.finalizaTransaction();
	}
	
	public void finalizaSessao() {
        
		HibernateUtility.closeSession();
	}

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
