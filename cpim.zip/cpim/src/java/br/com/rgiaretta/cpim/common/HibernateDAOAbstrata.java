package br.com.rgiaretta.cpim.common;

import org.hibernate.Session;
import org.hibernate.Transaction;

public abstract class HibernateDAOAbstrata implements InterfaceDAO {

	protected Session sessao;
	protected Transaction transaction;
	
	public HibernateDAOAbstrata(Session sessao) {
		super();
	}

	public void initTransaction() {
        
	}
	
	public void finalizaTransaction() {
        HibernateUtility.confirma();
	}

    public void finalizaTransactionComExcecao () throws Exception {
        HibernateUtility.confirmaComExcecao();
    }

}