package br.com.rgiaretta.cpim.common;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

public interface InterfaceDAO {
	
	public void save(Object objeto);
	public List<Object> getList(String sql);
	public void delete(Object objeto);
	public Query getQuery(String sql);
	public List<Object> getList(Query query);
	public void initTransaction();
	public void finalizaSessao();
	public Session getSession();
}
