package br.com.rgiaretta.cpim.common;
 
public interface IConstants {

  public static final String SUCCESS_KEY = "success";
  public static final String CANCEL_KEY = "cancel";
  public static final String FAILURE_KEY = "failure";
  public static final String ERROR_KEY = "error";  

}