package br.com.rgiaretta.cpim.common;
  
public class DataAccessException extends ApplicationException {
	private static final long serialVersionUID = -1058480292555720132L;

	Throwable exceptionCause = null;
    
        
    public DataAccessException(String exceptionMsg) {
        super(exceptionMsg);
    }
    
    public DataAccessException(String exceptionMsg, Throwable exception){
       super(exceptionMsg);   
       exceptionCause = exception;
    }
    
    public void printStackTrace(){
        if (exceptionCause!=null){
           System.err.println("An exception has been caused by: ");
           exceptionCause.printStackTrace();
        }
    }
}