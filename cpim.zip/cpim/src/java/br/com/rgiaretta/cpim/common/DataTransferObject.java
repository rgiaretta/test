package br.com.rgiaretta.cpim.common;
 
public abstract class DataTransferObject {


  public DataTransferObject() {
  }

}