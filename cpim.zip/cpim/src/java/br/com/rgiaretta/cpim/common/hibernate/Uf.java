package br.com.rgiaretta.cpim.common.hibernate;

import br.com.rgiaretta.cpim.common.DataTransferObject;

public class Uf extends DataTransferObject implements java.io.Serializable {

	private static final long serialVersionUID = 8492496242165459927L;

	private Integer id;
	private String sigla;
	private String nome;
  
	
	public Uf() {}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getSigla() {
		return sigla;
	}

	public void setSigla(String sigla) {
		this.sigla = sigla;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	
}