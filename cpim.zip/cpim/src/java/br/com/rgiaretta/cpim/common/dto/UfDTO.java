package br.com.rgiaretta.cpim.common.dto;

import br.com.rgiaretta.cpim.common.DataTransferObject;

public class UfDTO extends DataTransferObject implements java.io.Serializable {


	private static final long serialVersionUID = -4261251450452693380L;

	private Integer   id;
	private String sigla;
	private String nome;


	public UfDTO() {} 

	public UfDTO(Integer id, String sigla, String nome) {
		super();
		this.id = id;
		this.sigla = sigla;
		this.nome = nome;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getSigla() {
		return sigla;
	}

	public void setSigla(String sigla) {
		this.sigla = sigla;
	}
}