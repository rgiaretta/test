/* Licence:
 *   Use this however/wherever you like, just don't blame me if it breaks anything.
 *
 * Credit:
 *   If you're nice, you'll leave this bit:
 *
 *   Class by Pierre-Alexandre Losson -- http://www.telio.be/blog
 *   email : plosson@users.sourceforge.net
 */
/*
 *  Changed for Part 2, by Ken Cochrane
 *  http://KenCochrane.net , http://CampRate.com , http://PopcornMonsters.com
 */
package br.com.rgiaretta.cpim.common;
//package be.telio.mediastore.ui.upload;
import java.io.Serializable;

import org.apache.log4j.Logger;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by IntelliJ IDEA.
 *
 * @author Original : plosson on 06-janv.-2006 15:05:44 - Last modified  by $Author: vde $ on $Date: 2004/11/26 22:43:57 $
 * @version 1.0 - Rev. $Revision: 1.2 $
 */
public class UploadListener implements OutputStreamListener, Serializable {

	private static final long serialVersionUID = -6241751704098933444L;

	Logger log = Logger.getLogger(this.getClass());

	private HttpServletRequest request;

	private long delay = 0;

	private long startTime = 0;

	private int totalToRead = 0;

	private int totalBytesRead = 0;

	private int totalFiles = -1;
	
	
	
	
	private Estatisticas estatisticas;

	public UploadListener(HttpServletRequest request, long debugDelay) {
		this.request = request;
		this.delay = debugDelay;
		this.totalToRead = request.getContentLength();
		this.startTime = System.currentTimeMillis();
		this.estatisticas = new Estatisticas(totalToRead);
	}

	public void start() {
		this.totalFiles++;
		updateUploadInfo("start");
	}

	public void bytesRead(int bytesRead) {
		//this.bytesRead += bytesRead;
		this.estatisticas.setBytesLidos(this.estatisticas.getBytesLidos() + bytesRead);
		this.totalBytesRead = this.totalBytesRead + bytesRead;
		updateUploadInfo("progress");
		
		try {
			Thread.sleep(delay);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public void error(String message) {
		updateUploadInfo("error");
	}

	public void done() {
		updateUploadInfo("done");
	}

	private long getDelta() {
		return (System.currentTimeMillis() - this.startTime) / 1000;
	}
	long bps = 0;
	long tempoEstimado = 0;
	private void updateUploadInfo(String status) {
		
		this.log.debug("inside updateUploadInfo ");
		long delta = getDelta();
		//this.d2 = delta;
		this.estatisticas.setDelta(delta);
		if(this.estatisticas.maiorQueUmSegundo()) {
			//this.estatisticas.calcular();
			bps = this.estatisticas.getBps();
			tempoEstimado = this.estatisticas.getTempoEstimado(totalBytesRead);
			this.estatisticas.setBytesLidos(0);
			/*if(this.bytesRead != 0) {
				bps = Math.abs(this.bytesRead);
				tempoEstimado = (this.totalToRead - Math.abs(totalBytesRead)) / bps;
			}
			this.bytesRead = 0;
			
			d1 = d2;
			d2 = 0;*/
		 }
		
		
		this.log.debug("updateUploadInfo delta =  " + delta);
		UploadInfo upInfo = new UploadInfo(this.totalFiles, this.totalToRead,
				this.totalBytesRead, delta, status);
		
		upInfo.setBps(this.estatisticas.formataBps(bps));
		upInfo.setBytesLidos(this.estatisticas.formataBytes(this.totalBytesRead));
		upInfo.setBytesTotal(this.estatisticas.formataBytes(this.totalToRead));
		upInfo.setBytesFaltam(this.estatisticas.formataBytes(this.totalToRead - this.totalBytesRead));
		
		this.log.debug(upInfo);
		this.request.getSession().setAttribute("uploadInfo", upInfo);
		this.log.debug("leaving updateUploadInfo ");
	}

}
