package br.com.rgiaretta.cpim.usuario.service;

import java.util.Collection;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.HibernateException;

import br.com.rgiaretta.cpim.common.ApplicationException;
import br.com.rgiaretta.cpim.common.DataAccessException;
import br.com.rgiaretta.cpim.common.DataTransferObject;
import br.com.rgiaretta.cpim.common.HibernateDAO;
import br.com.rgiaretta.cpim.common.IBusiness;
import br.com.rgiaretta.cpim.usuario.model.UsuarioDAO;
import br.com.rgiaretta.cpim.usuario.hibernate.Usuario;


public class UsuarioBO implements IBusiness{

	private Log log = LogFactory.getLog(UsuarioBO.class);
	
  public UsuarioBO() {}
  
  
	public Integer add(DataTransferObject addRecord) throws ApplicationException {

		HibernateDAO dao = HibernateDAO.getDAO();
		Integer idUsuario = 0;

		try {

			UsuarioDAO usuarioDAO = new UsuarioDAO(dao);
			idUsuario = usuarioDAO.insert(addRecord);
			
			dao.finalizaTransaction();

		} catch(HibernateException e) {
			dao.getSession().getTransaction().rollback();
			log.error("Erro ao inserir Usuario", e);
            throw new DataAccessException("Erro em UsuarioBO.commit(): " + e.toString(), e);        

		} catch (Exception e) {
			dao.getSession().getTransaction().rollback();
			log.error("Erro ao inserir Usuario", e);
            throw new DataAccessException("Erro em UsuarioBO.commit(): " + e.toString(), e);        
		}
		
		finally {
			dao.finalizaSessao();
		}	  

		return idUsuario;
	}
 
  public Collection<?> findTop() throws ApplicationException {return null;}
  
  public DataTransferObject retrieve(Integer primaryKey) { 
  
		HibernateDAO dao = HibernateDAO.getDAO();
		Usuario usuario = null;
	    
	    try {
	    	      
	      UsuarioDAO usuarioDAO = new UsuarioDAO(dao);

	      usuario = (Usuario) usuarioDAO.findByPK(primaryKey);
	  
		} catch(HibernateException e) {
			dao.getSession().getTransaction().rollback();
			log.error("Erro ao obter Cliente", e);
            throw new DataAccessException("Erro em ClienteBO.commit(): " + e.toString(), e);        

		} catch (Exception e) {
			dao.getSession().getTransaction().rollback();
			log.error("Erro ao obter Cliente", e);
            throw new DataAccessException("Erro em ClienteBO.commit(): " + e.toString(), e);        

		} finally {
			dao.finalizaSessao();
		}	
		
		return usuario;
		
  }  // retrieve()
  

	public void update(DataTransferObject updateRecord) throws ApplicationException {
		
		HibernateDAO dao = HibernateDAO.getDAO();
	    
	    try {
	    	      
	      UsuarioDAO usuarioDAO = new UsuarioDAO(dao);
	      usuarioDAO.update(updateRecord);
	      
	      dao.finalizaTransaction();
	  
		} catch(HibernateException e) {
			dao.getSession().getTransaction().rollback();
			log.error("Erro ao alterar Usuario", e);
            throw new DataAccessException("Erro em UsuarioBO.commit(): " + e.toString(), e);        

		} catch (Exception e) {
			dao.getSession().getTransaction().rollback();
			log.error("Erro ao alterar Usuario", e);
            throw new DataAccessException("Erro em UsuarioBO.commit(): " + e.toString(), e);        

		} finally {
			dao.finalizaSessao();
		}	
		
	}

	
}