package br.com.rgiaretta.cpim.common;
 

public interface IBusiness {

  public Integer add(DataTransferObject addRecord) throws ApplicationException;
  public DataTransferObject retrieve(Integer primaryKey);
  public void update(DataTransferObject updateRecord) throws ApplicationException;
}