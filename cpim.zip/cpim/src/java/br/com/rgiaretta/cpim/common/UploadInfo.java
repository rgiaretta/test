/* Licence:
 *   Use this however/wherever you like, just don't blame me if it breaks anything.
 *
 * Credit:
 *   If you're nice, you'll leave this bit:
 *
 *   Class by Pierre-Alexandre Losson -- http://www.telio.be/blog
 *   email : plosson@users.sourceforge.net
 */
/*
 *  Changed for Part 2, by Ken Cochrane
 *  http://KenCochrane.net , http://CampRate.com , http://PopcornMonsters.com
 */
package br.com.rgiaretta.cpim.common;

import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 *
 * @author Original : plosson on 06-janv.-2006 12:19:14 - Last modified  by $Author: vde $ on $Date: 2004/11/26 22:43:57 $
 * @version 1.0 - Rev. $Revision: 1.2 $
 */
public class UploadInfo implements Serializable {
	

	private static final long serialVersionUID = -6411398094868893251L;

	private long totalSize = 0;

	private long bytesRead = 0;

	private long elapsedTime = 0;

	private String status = "done";

	private int fileIndex = 0;

	
	/* atributos formatados da informacao  */
	private String tempoTermino = "";
	private String bps = "";
	private String bytesLidos = "";
	private String bytesTotal = "";
	private String bytesFaltam = "";
	/**
	 * 
	 */
	public UploadInfo() {
	}

	/**
	 * 
	 * @param fileIndex
	 * @param totalSize
	 * @param bytesRead
	 * @param elapsedTime
	 * @param status
	 */
	public UploadInfo(int fileIndex, long totalSize, long bytesRead,
			long elapsedTime, String status) {
		this.fileIndex = fileIndex;
		this.totalSize = totalSize;
		this.bytesRead = bytesRead;
		this.elapsedTime = elapsedTime;
		this.status = status;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public long getTotalSize() {
		return totalSize;
	}

	public void setTotalSize(long totalSize) {
		this.totalSize = totalSize;
	}

	public long getBytesRead() {
		return bytesRead;
	}

	public void setBytesRead(long bytesRead) {
		this.bytesRead = bytesRead;
	}

	public long getElapsedTime() {
		return elapsedTime;
	}

	public void setElapsedTime(long elapsedTime) {
		this.elapsedTime = elapsedTime;
	}

	public boolean isInProgress() {
		return "progress".equals(status) || "start".equals(status);
	}

	public int getFileIndex() {
		return fileIndex;
	}

	public void setFileIndex(int fileIndex) {
		this.fileIndex = fileIndex;
	}

	/**
	 * 
	 */
	@Override
	public String toString() {
		return "[UploadInfo]\n" + 
				" totalSize= " + this.totalSize + "\n" + 
				" bytesRead= " + this.bytesRead + "\n" + 
				" elapsedTime= " + this.elapsedTime + "\n" + 
				" status= '" + this.status + "'\n" + 
				" fileIndex= " + this.fileIndex + "\n" + 
				" tempoTermino= '" + this.tempoTermino + "'\n" + 
				" bps= '" + this.bps + "'\n" +
				" bytesLidos= '" + this.bytesLidos + "'\n" +
				" bytesTotal= '" + this.bytesTotal + "'\n" +
				" bytesFaltam= '" + this.bytesFaltam + "'\n" +
				"[/ UploadInfo]\n";
	}

	/**
	 * @return the tempoTermino
	 */
	public String getTempoTermino() {
		return this.tempoTermino;
	}

	/**
	 * @param tempoTermino the tempoTermino to set
	 */
	public void setTempoTermino(String tempoTermino) {
		this.tempoTermino = tempoTermino;
	}

	/**
	 * @param formataBps
	 */
	public void setBps(String bps) {
		this.bps = bps;
		
	}

	/**
	 * @return the bps
	 */
	public String getBps() {
		return this.bps;
	}

	/**
	 * @return the bytesLidos
	 */
	public String getBytesLidos() {
		return this.bytesLidos;
	}

	/**
	 * @param bytesLidos the bytesLidos to set
	 */
	public void setBytesLidos(String bytesLidos) {
		this.bytesLidos = bytesLidos;
	}

	/**
	 * @return the bytesTotal
	 */
	public String getBytesTotal() {
		return this.bytesTotal;
	}

	/**
	 * @param bytesTotal the bytesTotal to set
	 */
	public void setBytesTotal(String bytesTotal) {
		this.bytesTotal = bytesTotal;
	}

	/**
	 * @return the bytesFaltam
	 */
	public String getBytesFaltam() {
		return this.bytesFaltam;
	}

	/**
	 * @param bytesFaltam the bytesFaltam to set
	 */
	public void setBytesFaltam(String bytesFaltam) {
		this.bytesFaltam = bytesFaltam;
	}

}
