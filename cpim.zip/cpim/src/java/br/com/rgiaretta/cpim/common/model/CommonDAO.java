package br.com.rgiaretta.cpim.common.model;

import java.util.ArrayList;
import java.util.Collection;

import org.hibernate.HibernateException;
import org.hibernate.Query;

import br.com.rgiaretta.cpim.common.DataAccessException;
import br.com.rgiaretta.cpim.common.DataTransferObject;
import br.com.rgiaretta.cpim.common.HibernateDAO;
import br.com.rgiaretta.cpim.common.IDataAccessObject;
import br.com.rgiaretta.cpim.common.dto.UfDTO;
import br.com.rgiaretta.cpim.common.hibernate.Uf;


public class CommonDAO implements IDataAccessObject {

	private HibernateDAO dao = null;

	public CommonDAO(HibernateDAO dao) throws DataAccessException {
		this.dao = dao;
	}

	public DataTransferObject findByPK(Integer primaryKey) throws DataAccessException {return null;} 

	public Integer insert(DataTransferObject insertRecord) throws DataAccessException {return null;} 

	public void update(DataTransferObject updateRecord) throws DataAccessException {};

	
	public Collection<UfDTO> getUfs() {

		Collection<UfDTO> ufs = new ArrayList<UfDTO>();

		try{

			Query q = dao.getSession().createQuery("FROM Uf");

			Collection<?> resultList = q.list();
			
			if(resultList != null && resultList.size() > 0){
			
				for (Object obj : resultList) {
					
					Uf uf = (Uf)obj;
					UfDTO ufDTO = new UfDTO();
					ufDTO.setId(uf.getId());
					ufDTO.setSigla(uf.getSigla());
					ufDTO.setNome(uf.getNome());
					
					ufs.add(ufDTO);
					
				}
								
			}


		  } catch (HibernateException e) {
			e.printStackTrace();
			throw new RuntimeException("error.Common.getGruposAcesso");
		} 

		return ufs;
	}	
		  
}