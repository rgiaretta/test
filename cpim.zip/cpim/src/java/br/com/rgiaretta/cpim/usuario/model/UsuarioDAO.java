package br.com.rgiaretta.cpim.usuario.model;

import org.hibernate.HibernateException;

import br.com.rgiaretta.cpim.common.DataAccessException;
import br.com.rgiaretta.cpim.common.DataTransferObject;
import br.com.rgiaretta.cpim.common.HibernateDAO;
import br.com.rgiaretta.cpim.common.IDataAccessObject;
import br.com.rgiaretta.cpim.usuario.hibernate.Usuario;



public class UsuarioDAO implements IDataAccessObject {

  private HibernateDAO dao = null;
  
  public UsuarioDAO(HibernateDAO dao) throws DataAccessException {
    this.dao = dao;
  }
  
  
  public DataTransferObject findByPK(Integer primaryKey) throws DataAccessException {
	  
	  Usuario usuario = (Usuario) dao.getSession().get(Usuario.class, primaryKey);
	  return usuario;
	  
  }

    
  public Integer insert(DataTransferObject insertRecord) throws DataAccessException {
 	  
	  Integer idUsuario = 0;

	  try {

		  Usuario usuario = new Usuario(); 
		  usuario = (Usuario) insertRecord;

		  this.dao.getSession().saveOrUpdate(usuario);
		  this.dao.getSession().flush();
		  
		  idUsuario = usuario.getId();

	  } catch (HibernateException e) {
		  e.printStackTrace();
		  throw new RuntimeException("error.Usuario.insert");
	  } 
	  
	  return idUsuario;
    
  } 
  
  public void update(DataTransferObject updateRecord) throws DataAccessException {

	  try {

		  Usuario usuario = (Usuario) updateRecord;

		  this.dao.getSession().saveOrUpdate(usuario);
		  this.dao.getSession().flush();
		  
	  } catch (HibernateException e) {
		  e.printStackTrace();
		  throw new RuntimeException("error.Usuario.update");
	  } 	 	  
	  
  }
  
  
  
  public void delete(DataTransferObject deleteRecord) throws DataAccessException {}
  
}