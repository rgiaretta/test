package br.com.rgiaretta.cpim.common;
 

public interface IDataAccessObject {

	public DataTransferObject findByPK(Integer primaryKey) throws DataAccessException;
	public Integer insert(DataTransferObject insertRecord) throws DataAccessException;
	public void update(DataTransferObject updateRecord) throws DataAccessException;

	public Propriedade prop = new Propriedade("conf.properties");
	public String limit = prop.getPropriedade("bd.limit");
	public String limit_string = prop.getPropriedade("bd.limit.string");
	public String offset_string = prop.getPropriedade("bd.offset.string");
	public String limit_string_pos = prop.getPropriedade("bd.limit.string.pos");	

}