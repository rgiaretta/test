package br.com.rgiaretta.cpim.usuario.dto;

import java.sql.Date;

import br.com.rgiaretta.cpim.common.DataTransferObject;

public class UsuarioDTO extends DataTransferObject implements java.io.Serializable {

	private static final long serialVersionUID = -5879598604269321418L;
	
	private Integer id;
	private String nome;
	private String email;	
	private Date dataCadastro;
	private Boolean ativo;
	private String  dispatch;
	private String  tipoFormulario;
	private String  actionRetorno;
	private String sexo;
	private String uf;

  
	
	public UsuarioDTO() {}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}


	public java.sql.Date getDataCadastro() {
		return dataCadastro;
	}

	public void setDataCadastro(java.sql.Date dataCadastro) {
		this.dataCadastro = dataCadastro;
	}
	
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}	

	public Boolean getAtivo() {
		return ativo;
	}

	public void setAtivo(Boolean ativo) {
		this.ativo = ativo;
	}	

	public String getDispatch() {
		return dispatch;
	}

	public void setDispatch(String dispatch) {
		this.dispatch = dispatch;
	}

	public String getTipoFormulario() {
		return tipoFormulario;
	}

	public void setTipoFormulario(String tipoFormulario) {
		this.tipoFormulario = tipoFormulario;
	}

	public String getActionRetorno() {
		return actionRetorno;
	}

	public void setActionRetorno(String actionRetorno) {
		this.actionRetorno = actionRetorno;
	}


	public String getSexo() {
		return sexo;
	}

	public void setSexo(String sexo) {
		this.sexo = sexo;
	}

	public String getUf() {
		return uf;
	}

	public void setUf(String uf) {
		this.uf = uf;
	}	
	
}